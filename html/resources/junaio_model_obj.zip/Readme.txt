//-----------------------------------------------------------------------------
//
// Copyright (C) 2010  by Oliver Gerl, metaio GmbH
//
//  You may use this model and all belonging files (material, Texture) for the purpose of testing within the junaio platform only.
//-----------------------------------------------------------------------------
