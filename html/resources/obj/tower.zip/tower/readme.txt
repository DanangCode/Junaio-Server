Notes


---------------------
Copyright, exemption from responsibility, etc. 
---------------------

 3dchaya which are the authors hold the copyright of a model file, and the right of other all.
No obstacles and damage which were generated in use of a model file take responsibility.
Please understand the situation beforehand and use on each one of responsibility.
A model file and its contents of description may be changed without a preliminary announcement. 


---------------------
Consent of files use / distribution conditions etc.
---------------------
Model files are freeware.
Distribution for a third person is prohibition.
There is no restriction using a model.It can be used freely.
Please contact me in advance,In distribution of printing to books, a magazine, etc., and the commercial
purpose. 


---------------------
Contact
---------------------
The comment and request, and bug which use this model -- if there is a report etc, please inform an address in an E-mail 



Author�F3dchaya
Home Page URL�F3dchaya.com
E-Mail�Finformation@3dchaya.com