<?php
/**
 * @copyright  Copyright 2009 metaio GmbH. All rights reserved.
 * @link       http://www.metaio.com
 * @author     Bernhard Heindl
 **/

//General channel stuff
define('JUNAIO_API_HOST', 'http://api.junaio.com'); // URL to the junaio API
define('AUTH_DATE_TOLERANCE', 15 * 60 * 1000);	// Set time period for valid requests: 15 minutes
define('JUNAIO_KEY', 'Your_API_KEY_HERE'); // Junaio developer key
